{% block content %}
{% endblock %}      --> 레이아웃 형식  ( block contet 와 end block 사이에 있는 것들을 제외하고 나머지 부분은 레이아웃이 됨.)


{% extends "home.html" %}
{% block content %}
  추가 꾸밀 내용
{% endblock %}      --> 이 코드만 쓰고 추가 꾸밀 내용에 붙여넣기 하면 됨.       // python 확장자 켜줘야 됨

	
<button type="button" onclick="init2()">사진</button> 

async function init2() {
			const modelURL = URL + "model.json";
			const metadataURL = URL + "metadata.json";

			// load the model and metadata
			// Refer to tmImage.loadFromFiles() in the API to support files from a file picker
			// or files from your local hard drive
			// Note: the pose library adds "tmImage" object to your window (window.tmImage)
			model = await tmImage.load(modelURL, metadataURL);
			maxPredictions = model.getTotalClasses();


			// append elements to the DOM
			document.getElementById("webcam-container").appendChild(webcam.canvas);
			labelContainer = document.getElementById("label-container");
			for (let i = 0; i < maxPredictions; i++) { // and class labels
				labelContainer.appendChild(document.createElement("div"));
			}
		}

async function capture() {
			webcam.update(); // update the webcam frame
			await predict1();
			window.requestAnimationFrame(capture);
		}

async function predict1() {
			// predict1 can take in an image, video or canvas html element
      var image = document.getElementById("face-image")
			const prediction = await model.predict1(image, false);
			for (let i = 0; i < maxPredictions; i++) {
				const classPrediction =
					prediction[i].className + ": " + prediction[i].probability.toFixed(2);
				labelContainer.childNodes[i].innerHTML = classPrediction;
			}
		}

