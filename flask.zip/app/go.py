from flask import Flask, render_template, request
 
app = Flask(__name__)      
 
@app.route('/')
def home():
  return render_template('home.html')
 
@app.route('/check')
def check():
  return render_template('check.html')

@app.route('/training')
def training():
  return render_template('training.html')

@app.route('/guide')
def test():
  return render_template('guide.html')





if __name__ == '__main__':
  app.run(debug=True)