from flask import Flask, render_template
 
app = Flask(__name__)      
 
@app.route('/')
def home():
  return render_template('home.html')
 
@app.route('/analyze')
def analyze():
  return render_template('analyze.html')

@app.route('/training')
def training():
  return render_template('training.html')

@app.route('/123')
def machine():
  return render_template('test.html')

if __name__ == '__main__':
  app.run(debug=True)
  